// Interacciones de la presentación BARF
(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  // Navegación móvil
  const menuToggle = $("#menuToggle");
  const mainNav = $("#mainNav");
  menuToggle.addEventListener("click", () => {
    const open = mainNav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(open));
  });
  $$("#mainNav a").forEach(link => link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  }));

  // Barra de lectura y botón volver arriba
  const progress = $("#readingProgress");
  const backTop = $("#backTop");
  const updateScrollUI = () => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    progress.style.width = `${max > 0 ? (window.scrollY / max) * 100 : 0}%`;
    backTop.classList.toggle("visible", window.scrollY > 500);
  };
  window.addEventListener("scroll", updateScrollUI, { passive: true });
  updateScrollUI();
  backTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  // Aparición progresiva de elementos
  const revealItems = $$(".reveal");
  if ("IntersectionObserver" in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach(item => observer.observe(item));
  } else {
    revealItems.forEach(item => item.classList.add("visible"));
  }

  // Modo presentación: una sección por pantalla, navegación con teclado
  const presentationBtn = $("#presentationBtn");
  const hud = $("#presentationHud");
  const slides = $$("main > section");
  const counter = $("#slideCounter");
  const prev = $("#prevSlide");
  const next = $("#nextSlide");
  const exit = $("#exitPresentation");
  let slideIndex = 0;
  let presentationActive = false;

  const updateSlide = () => {
    slides.forEach((slide, index) => slide.classList.toggle("active-slide", index === slideIndex));
    counter.textContent = `${String(slideIndex + 1).padStart(2, "0")} / ${String(slides.length).padStart(2, "0")}`;
    prev.disabled = slideIndex === 0;
    next.disabled = slideIndex === slides.length - 1;
    prev.style.opacity = prev.disabled ? ".35" : "1";
    next.style.opacity = next.disabled ? ".35" : "1";
    const active = slides[slideIndex];
    if (active) active.scrollTop = 0;
  };

  const startPresentation = async () => {
    if (presentationActive) return;
    presentationActive = true;
    slideIndex = 0;
    document.body.classList.add("presentation-mode");
    updateSlide();
    try {
      if (document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen();
    } catch (error) {
      // El modo presentación continúa disponible aunque el navegador no permita fullscreen.
    }
  };

  const stopPresentation = async () => {
    presentationActive = false;
    document.body.classList.remove("presentation-mode");
    slides.forEach(slide => slide.classList.remove("active-slide"));
    if (document.fullscreenElement && document.exitFullscreen) {
      try { await document.exitFullscreen(); } catch (error) {}
    }
  };

  const moveSlide = direction => {
    if (!presentationActive) return;
    slideIndex = Math.max(0, Math.min(slides.length - 1, slideIndex + direction));
    updateSlide();
  };

  presentationBtn.addEventListener("click", startPresentation);
  prev.addEventListener("click", () => moveSlide(-1));
  next.addEventListener("click", () => moveSlide(1));
  exit.addEventListener("click", stopPresentation);
  document.addEventListener("keydown", event => {
    if (!presentationActive) return;
    if (["ArrowRight", "PageDown", " "].includes(event.key)) {
      event.preventDefault(); moveSlide(1);
    } else if (["ArrowLeft", "PageUp"].includes(event.key)) {
      event.preventDefault(); moveSlide(-1);
    } else if (event.key === "Escape" && !document.fullscreenElement) {
      stopPresentation();
    }
  });
  document.addEventListener("fullscreenchange", () => {
    if (!document.fullscreenElement && presentationActive) {
      presentationActive = false;
      document.body.classList.remove("presentation-mode");
      slides.forEach(slide => slide.classList.remove("active-slide"));
    }
  });
})();